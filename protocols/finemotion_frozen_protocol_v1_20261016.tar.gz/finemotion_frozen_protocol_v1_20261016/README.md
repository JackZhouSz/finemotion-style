# FineMotion frozen protocol v1 (ID lists only)

This release candidate contains 292 saved ID-list files and project documentation.
It contains no captions, source labels, motions, videos, meshes, body-model weights,
or source-to-crop conversion ledger. No Hugging Face upload has been performed.

The intended distribution pairs a ready-to-use Bandai motion/text example with
official acquisition and local reconstruction instructions for the other five
sources. This metadata asset preserves historical dataset and benchmark memberships
across those sources; it does not grant access to their data or override their terms.

## Counts and paths

- `frozen_protocol_reference/splits/base263_v1/`: saved full base feature/caption
  ID pool, 67,907 IDs (54,360 train / 6,749 validation / 6,798 test).
- `frozen_protocol_reference/splits/training_pose69_v1/`: saved pose69-available
  pool, 59,038 IDs (47,236 / 5,866 / 5,936). The paper reports 59,039; the one-ID
  historical difference is unresolved. No replacement ID has been invented.
- `frozen_protocol_reference/benchmarks/paper_benchmark_v1/lists/style/`: March 1
  strict, single-family caption-derived style lists from the 67,907-ID base pool,
  13,357 IDs: Impact 4,196 / Strike 3,809 / Balance 4,726 / Shake 626.
  Storage name `tremor` means the paper's Shake class.
- `frozen_protocol_reference/benchmarks/pose69_available_style_v1/single_strict/`:
  a distinct availability-filtered view with 11,591 IDs. This is the intersection
  of the March strict lists with the saved pose69 keep IDs. The asset retains
  additional historical aliases, attributes and permissive classification views;
  these must not be counted as additional unique motion clips.
- `frozen_protocol_reference/benchmarks/paper_benchmark_v1/lists/content/`: original
  January 7 HumanML3D content lists, union 9,510. The separately saved-partition
  assigned view under `derived/content_assigned/` has 9,508. Original Walk IDs
  `009707` and `M009707` have no saved partition and remain unassigned.

The base pool, available pool, strict style benchmark and content subset have
different roles. General model training used the complete available training
split across sources, not only the four style families. Frozen partitions are
segment-level historical assignments; overlapping windows of a parent recording
can occur in different splits. This asset is not a recording-grouped split.

## Rebuild and versioning

Acquire source data from the official dataset providers and follow the source
conversion and text-production instructions in the FineMotion GitHub repository:
https://github.com/dongran/finemotion-style

The source-to-segment/crop acquisition and conversion ledger is a separate material;
it is not included here and cannot be inferred from every ID alone. Pair these
lists with the correct conversion output and clip IDs before training. An ID match
does not by itself verify coordinates, frame rate, crop boundaries or motion quality.

VLM-generated captions are not guaranteed to be bit-for-bit or word-for-word equal
to historical captions, even when the prompt, model and inputs are retained.
Regenerating captions must not silently change these frozen IDs or partitions.
Publish new captions as a named text version with hashes; if recomputing the four
caption-derived classes, create a new benchmark version and retain this reference.
Frozen style memberships record historical text heuristics, not human-verified
motion mechanisms. Exact paper metric reproduction additionally needs the relevant
evaluation pair/selection manifests, model and evaluator checkpoints, and settings.

## Integrity and licence scope

Every original ID-list byte and within-file order is preserved. `manifest.json`
records the source archive, per-list SHA-256, sizes and counts. `SHA256SUMS` covers
all payload files except itself. The external archive checksum covers the tar.gz.

The project's ID-protocol documentation/materials are distributed with the project
MIT licence in `LICENSE`. Third-party datasets, source metadata, generated captions,
body-model assets and reconstruction dependencies retain their own applicable
terms; this licence does not relicense them. They are not included in this asset.
